import xbmcaddon

MainBase = 'http://bit.ly/2hagbbr'
addon = xbmcaddon.Addon('plugin.video.tugak')