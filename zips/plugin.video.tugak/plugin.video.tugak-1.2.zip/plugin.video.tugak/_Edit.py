import xbmcaddon

MainBase = 'http://bit.ly/2lUhbG5'
addon = xbmcaddon.Addon('plugin.video.tugak')